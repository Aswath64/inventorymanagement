# Inventory Management System

A complete Inventory Management System built with Spring Boot (Backend) and React + Vite (Frontend).

## Features

### Authentication & User Roles
- JWT-based authentication
- User registration (default role: CUSTOMER)
- Forgot password with OTP via Brevo SMTP
- Role-based access control (ADMIN, STAFF, CUSTOMER)

### Product & Category Management (Admin)
- CRUD operations for categories
- Product management with multiple image upload
- Product search, filtering, and pagination
- Product reviews and ratings

### Customer Features
- Browse products by category
- Search products
- Shopping cart
- Wishlist
- Order placement
- Product reviews (only for purchased products)
- Order history with PDF/Excel reports
- Profile management

### Order Management
- Customer checkout
- Staff order processing (Pending → Processing → Shipped → Delivered)
- Admin order assignment to staff
- Order tracking and status updates

### Notification System
- Email notifications for orders
- In-app notifications
- Low stock alerts for admin

### Dashboards
- Customer Dashboard: Order count, recent orders, wishlist count
- Staff Dashboard: Pending orders, completed orders, today's orders
- Admin Dashboard: Total products, customers, staff, sales, monthly revenue, low stock alerts

### Reports
- Sales reports (PDF/Excel)
- Product stock reports (PDF/Excel)
- Order reports (Excel)
- Staff activity reports (Excel)
- Customer order history (PDF/Excel)

## Tech Stack

### Backend
- Spring Boot 3.2.0
- Spring Security with JWT
- Spring Data JPA
- MySQL Database
- Brevo SMTP for emails
- OpenPDF for PDF generation
- Apache POI for Excel generation

### Frontend
- React 18
- Vite
- React Router
- Axios
- Tailwind CSS

## Setup Instructions

### Backend Setup

1. Navigate to backend directory:
```bash
cd backend
```

2. Configure `application.properties`:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/inventory_db
spring.datasource.username=your_username
spring.datasource.password=your_password

BREVO_SMTP_USERNAME=your_brevo_username
BREVO_SMTP_PASSWORD=your_brevo_password
EMAIL_SENDER_ADDRESS=your_email@example.com
JWT_SECRET=your-256-bit-secret-key-minimum-32-characters
```

3. Create MySQL database:
```sql
CREATE DATABASE inventory_db;
```

4. Run the application:
```bash
mvn spring-boot:run
```

Backend will run on `http://localhost:8080`

### Frontend Setup

1. Navigate to frontend directory:
```bash
cd frontend
```

2. Install dependencies:
```bash
npm install
```

3. Configure `.env`:
```
VITE_API_BASE_URL=http://localhost:8080/api
```

4. Run the development server:
```bash
npm run dev
```

Frontend will run on `http://localhost:5173`

## API Endpoints

### Authentication
- `POST /api/auth/login` - Login
- `POST /api/auth/register` - Register
- `POST /api/auth/forgot-password` - Send OTP
- `POST /api/auth/validate-otp` - Validate OTP
- `POST /api/auth/reset-password` - Reset password

### Products (Public)
- `GET /api/products` - List products with pagination, search, filters
- `GET /api/products/{id}` - Get product details
- `GET /api/products/category/{categoryId}` - Get products by category

### Admin Endpoints
- `GET /api/admin/categories` - List categories
- `POST /api/admin/categories` - Create category
- `PUT /api/admin/categories/{id}` - Update category
- `DELETE /api/admin/categories/{id}` - Delete category
- `POST /api/admin/products` - Create product with images
- `PUT /api/admin/products/{id}` - Update product
- `DELETE /api/admin/products/{id}` - Delete product
- `GET /api/admin/orders` - List all orders
- `PUT /api/admin/orders/{id}/assign` - Assign order to staff
- `GET /api/admin/dashboard` - Admin dashboard data
- `GET /api/admin/users` - Paginated user search
- `POST /api/admin/users` - Create user with role assignment
- `PUT /api/admin/users/{id}` - Update user details/role
- `DELETE /api/admin/users/{id}` - Remove user
- `GET /api/admin/reports/*` - Generate reports

### Staff Endpoints
- `GET /api/staff/orders` - Get assigned orders
- `PUT /api/staff/orders/{id}/status` - Update order status
- `GET /api/staff/dashboard` - Staff dashboard data
- `GET /api/staff/reports/orders` - Generate staff reports

### Customer Endpoints
- `GET /api/customer/dashboard` - Customer dashboard
- `GET /api/customer/cart` - Get cart
- `POST /api/customer/cart/add` - Add to cart
- `PUT /api/customer/cart/{id}` - Update cart item
- `DELETE /api/customer/cart/{id}` - Remove from cart
- `GET /api/customer/wishlist` - Get wishlist
- `POST /api/customer/wishlist/add/{productId}` - Add to wishlist
- `DELETE /api/customer/wishlist/{id}` - Remove from wishlist
- `POST /api/customer/orders/checkout` - Checkout
- `GET /api/customer/orders` - Get orders
- `PUT /api/customer/orders/{id}/cancel` - Cancel pending/processing order
- `POST /api/customer/reviews` - Add review
- `GET /api/profile` - Get profile/settings (all roles)
- `PUT /api/profile` - Update profile (all roles)
- `PUT /api/profile/password` - Change password (all roles)
- `PUT /api/profile/settings` - Update appearance/notification preferences

## Database Schema

The application uses JPA with Hibernate auto-ddl. Tables are created automatically:
- users
- categories
- products
- product_images
- cart
- wishlist
- orders
- order_items
- reviews
- notifications
- otp_tokens

## Security

- JWT tokens with expiration
- BCrypt password encryption
- Role-based access control
- CORS configuration
- Input validation

## File Upload

Product images are stored in `uploads/products/{productId}/` directory and served via `/api/images/**` endpoint.
Uploaded files keep their original names (only a random UUID prefix is added to guarantee uniqueness). Files are stored under `uploads/products/{productId}/` and exposed via `/api/images/products/{productId}/{filename}`.

## License

This project is for educational purposes.

#   i n f o s y s  
 