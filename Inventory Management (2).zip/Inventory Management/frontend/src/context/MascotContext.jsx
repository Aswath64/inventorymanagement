import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { soundManager } from '../utils/soundUtils';

const MascotContext = createContext();

export const MascotProvider = ({ children }) => {
    // --- Persistent State ---
    const [xp, setXp] = useState(() => parseInt(localStorage.getItem('mascot_xp')) || 0);
    const [level, setLevel] = useState(1); // Derived from XP usually, but storing simple level for now
    const [isVisible, setIsVisible] = useState(() => {
        const saved = localStorage.getItem('mascot_visible');
        return saved !== null ? JSON.parse(saved) : true;
    });
    const [isMuted, setIsMuted] = useState(() => {
        const saved = localStorage.getItem('mascot_muted');
        return saved !== null ? JSON.parse(saved) : false;
    });

    // --- Volatile State ---
    const [emotion, setEmotion] = useState('idle'); // idle, happy, sad, surprised, sleeping, thinking, shy
    const [target, setTarget] = useState(null); // {x, y} for "Look At" behavior

    // --- Effects ---

    // Persist XP
    useEffect(() => {
        localStorage.setItem('mascot_xp', xp);
        // Simple level up logic: Level = 1 + floor(XP / 1000)
        const newLevel = 1 + Math.floor(xp / 1000);
        if (newLevel > level) {
            setLevel(newLevel);
            setEmotion('happy');
            soundManager.play('levelUp');
            setTimeout(() => setEmotion('idle'), 3000);
        }
    }, [xp, level]);

    // Persist Settings
    useEffect(() => {
        localStorage.setItem('mascot_visible', isVisible);
    }, [isVisible]);

    useEffect(() => {
        // SoundManager saves its own state too, but we sync here
        soundManager.setMute(isMuted);
    }, [isMuted]);

    // --- Actions ---

    const addXp = useCallback((amount) => {
        setXp((prev) => prev + amount);
    }, []);

    const triggerEmotion = useCallback((newEmotion, duration = 2000) => {
        setEmotion(newEmotion);
        if (newEmotion === 'happy') soundManager.play('success');
        if (newEmotion === 'sad') soundManager.play('error');
        if (newEmotion === 'surprised') soundManager.play('pop');
        if (newEmotion === 'shy') soundManager.play('whoosh');

        if (duration > 0) {
            setTimeout(() => {
                setEmotion((prev) => (prev === newEmotion ? 'idle' : prev));
            }, duration);
        }
    }, []);

    const lookAt = useCallback((x, y) => {
        setTarget({ x, y });
        // Reset target after a while if needed, or let component handle it
        setTimeout(() => setTarget(null), 3000);
    }, []);

    const toggleMute = useCallback(() => {
        setIsMuted((prev) => !prev);
    }, []);

    const toggleVisibility = useCallback(() => {
        setIsVisible((prev) => !prev);
    }, []);

    const value = {
        xp,
        level,
        emotion,
        target,
        isVisible,
        isMuted,
        addXp,
        setEmotion: triggerEmotion,
        lookAt,
        toggleMute,
        toggleVisibility,
    };

    return (
        <MascotContext.Provider value={value}>
            {children}
        </MascotContext.Provider>
    );
};

export const useMascot = () => {
    const context = useContext(MascotContext);
    if (!context) {
        throw new Error('useMascot must be used within a MascotProvider');
    }
    return context;
};
