import React, { useRef, useEffect, useState } from 'react';
import { motion, useAnimation, useDragControls } from 'framer-motion';
import { useMascot } from '../../context/MascotContext';
import { soundManager } from '../../utils/soundUtils';

// --- Simple 1D Perlin Noise Implementation ---
const noise = (x) => {
    x = (x << 13) ^ x;
    return (1.0 - ((x * (x * x * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824.0);
};

const interpolate = (a, b, t) => a * (1 - t) + b * t;

const perlin = (t) => {
    const i = Math.floor(t);
    const f = t - i;
    return interpolate(noise(i), noise(i + 1), f);
};

// --- Component ---
const FloatingBoxy = () => {
    const { emotion, target, isVisible, setEmotion, addXp, isMuted, toggleMute, toggleVisibility } = useMascot();
    const constraintsRef = useRef(null);
    const boxRef = useRef(null);

    // Physics State (using Refs for performance)
    const pos = useRef({ x: window.innerWidth / 2, y: window.innerHeight / 2 });
    const vel = useRef({ x: 0, y: 0 });
    const time = useRef(Math.random() * 100);
    const isDragging = useRef(false);
    const frameId = useRef(null);

    // Appearance State
    const [scale, setScale] = useState(1);
    const [rotation, setRotation] = useState(0);
    const controls = useAnimation(); // For visual updates

    // --- Physics Loop ---
    const updatePhysics = () => {
        if (!boxRef.current || isDragging.current) {
            if (isDragging.current) {
                // While dragging, just sync physics pos to actual element pos could be tricky avoiding cycles.
                // Actually, Framer Motion handles the drag visual. We just update our ref onDrag.
            } else {
                frameId.current = requestAnimationFrame(updatePhysics);
            }
            return;
        }

        // 1. Organic Wandering (Perlin Noise Force)
        time.current += 0.005;
        // Map noise (-1 to 1) to a small force
        const noiseX = perlin(time.current) * 0.5;
        const noiseY = perlin(time.current + 100) * 0.5;

        // 2. Apply Forces
        vel.current.x += noiseX;
        vel.current.y += noiseY;

        // 3. Friction/Damping
        vel.current.x *= 0.96; // Air resistance
        vel.current.y *= 0.96;

        // 4. Target Attraction (if "Look At" is active)
        if (target) {
            const dx = target.x - pos.current.x;
            const dy = target.y - pos.current.y;
            vel.current.x += dx * 0.002;
            vel.current.y += dy * 0.002;
        }

        // 5. Update Position
        pos.current.x += vel.current.x;
        pos.current.y += vel.current.y;

        // 6. Boundary Repulsion (Soft Walls)
        const margin = 50;
        const width = window.innerWidth;
        const height = window.innerHeight;

        if (pos.current.x < margin) vel.current.x += 0.5;
        if (pos.current.x > width - margin) vel.current.x -= 0.5;
        if (pos.current.y < margin) vel.current.y += 0.5;
        if (pos.current.y > height - margin) vel.current.y -= 0.5;

        // Hard Boundary Clamp (Just in case)
        pos.current.x = Math.max(0, Math.min(width, pos.current.x));
        pos.current.y = Math.max(0, Math.min(height, pos.current.y));

        // 7. Depth Illusion (Scale based on Y)
        // Top of screen = further away (0.85x), Bottom = closer (1.1x)
        const depthScale = 0.85 + (pos.current.y / height) * 0.25;
        setScale(depthScale);

        // 8. Rotation based on X velocity (lean into movement)
        const lean = vel.current.x * 2;
        setRotation(lean);

        // Apply to DOM
        controls.set({
            x: pos.current.x,
            y: pos.current.y,
            scale: depthScale,
            rotate: lean,
        });

        frameId.current = requestAnimationFrame(updatePhysics);
    };

    useEffect(() => {
        if (!isVisible) {
            if (frameId.current) cancelAnimationFrame(frameId.current);
            return;
        }

        // Start loop
        frameId.current = requestAnimationFrame(updatePhysics);
        return () => cancelAnimationFrame(frameId.current);
    }, [isVisible, target]);


    // --- Interactions ---

    const handleDragStart = () => {
        isDragging.current = true;
        setEmotion('surprised');
        soundManager.play('pop');
        if (frameId.current) cancelAnimationFrame(frameId.current);
    };

    const handleDragEnd = (event, info) => {
        isDragging.current = false;
        // Transfer drag velocity to physics velocity for "Throw" effect
        vel.current.x = info.velocity.x * 0.05; // Scale down for pixels/frame
        vel.current.y = info.velocity.y * 0.05;

        // Sync ref position to where drag ended
        pos.current.x = info.point.x;
        pos.current.y = info.point.y;

        setEmotion('happy');
        addXp(10); // Reward for playing
        soundManager.play('whoosh'); // Or similar

        // Resume loop
        frameId.current = requestAnimationFrame(updatePhysics);
    };

    const handleHover = () => {
        soundManager.play('hover');
        if (emotion === 'idle') setEmotion('happy');
    };

    if (!isVisible) return null;

    return (
        <>
            {/* Full screen constraints wrapper (invisible) */}
            <div
                ref={constraintsRef}
                className="fixed inset-0 pointer-events-none z-[9999]"
            />

            {/* The Mascot */}
            <motion.div
                ref={boxRef}
                drag
                dragConstraints={constraintsRef}
                dragElastic={0.2}
                dragMomentum={false} // We handle momentum manually
                onDragStart={handleDragStart}
                onDragEnd={handleDragEnd}
                onHoverStart={handleHover}
                animate={controls}
                initial={{ x: window.innerWidth / 2, y: window.innerHeight / 2 }}
                className="fixed top-0 left-0 w-24 h-24 pointer-events-auto cursor-grab active:cursor-grabbing z-[10000] drop-shadow-2xl"
            >
                {/* Boxy Visuals */}
                <div className={`relative w-full h-full bg-white/90 backdrop-blur-md rounded-3xl shadow-[0_0_40px_rgba(255,255,255,0.6)] border border-white/50 transition-colors duration-300
          ${emotion === 'sad' ? 'bg-blue-100/90' : ''}
          ${emotion === 'angry' ? 'bg-red-100/90' : ''}
        `}>
                    {/* Eyes Container */}
                    <div className="absolute top-1/3 w-full flex justify-center space-x-4">
                        {/* Left Eye */}
                        <div className="w-5 h-8 bg-slate-800 rounded-full overflow-hidden relative transition-all duration-300">
                            <div className="absolute top-1 right-1 w-2 h-2 bg-white rounded-full opacity-80" />
                            {emotion === 'sleeping' && <div className="absolute inset-0 bg-slate-300 translate-y-1" />}
                            {emotion === 'happy' && <div className="absolute bottom-0 w-full h-4 bg-slate-800 rounded-t-full translate-y-2 scale-y-50" />}
                        </div>
                        {/* Right Eye */}
                        <div className="w-5 h-8 bg-slate-800 rounded-full overflow-hidden relative transition-all duration-300">
                            <div className="absolute top-1 right-1 w-2 h-2 bg-white rounded-full opacity-80" />
                            {emotion === 'sleeping' && <div className="absolute inset-0 bg-slate-300 translate-y-1" />}
                            {emotion === 'happy' && <div className="absolute bottom-0 w-full h-4 bg-slate-800 rounded-t-full translate-y-2 scale-y-50" />}
                        </div>
                    </div>

                    {/* Mouth (Simple SVG or CSS) */}
                    <div className="absolute bottom-1/4 w-full flex justify-center">
                        {emotion === 'happy' && <div className="w-6 h-3 border-b-4 border-slate-800 rounded-b-full" />}
                        {emotion === 'surprised' && <div className="w-4 h-4 border-4 border-slate-800 rounded-full" />}
                        {emotion === 'sad' && <div className="w-6 h-3 border-t-4 border-slate-800 rounded-t-full translate-y-2" />}
                        {(emotion === 'idle' || emotion === 'sleeping') && <div className="w-4 h-1 bg-slate-800 rounded-full opacity-50" />}
                    </div>

                    {/* Accessories / Particles could go here */}

                    {/* Shy Hands (Covering Eyes) */}
                    {emotion === 'shy' && (
                        <>
                            <motion.div
                                initial={{ y: 20, opacity: 0 }}
                                animate={{ y: 0, opacity: 1 }}
                                className="absolute top-1/3 left-[20%] w-6 h-6 bg-slate-900 rounded-full z-10 shadow-lg border-2 border-white"
                            />
                            <motion.div
                                initial={{ y: 20, opacity: 0 }}
                                animate={{ y: 0, opacity: 1 }}
                                className="absolute top-1/3 right-[20%] w-6 h-6 bg-slate-900 rounded-full z-10 shadow-lg border-2 border-white"
                            />
                        </>
                    )}
                </div>

                {/* Control Bar (On Hover) */}
                <div className="absolute -bottom-12 left-1/2 -translate-x-1/2 flex space-x-2 opacity-0 hover:opacity-100 transition-opacity duration-300 pointer-events-auto">
                    <button
                        onClick={(e) => { e.stopPropagation(); toggleMute(); }}
                        className="w-8 h-8 rounded-full bg-white/80 backdrop-blur-md shadow-lg flex items-center justify-center text-xs hover:scale-110 transition-transform"
                        title={isMuted ? "Unmute" : "Mute"}
                    >
                        {isMuted ? '🔇' : '🔊'}
                    </button>
                    <button
                        onClick={(e) => { e.stopPropagation(); toggleVisibility(); }}
                        className="w-8 h-8 rounded-full bg-white/80 backdrop-blur-md shadow-lg flex items-center justify-center text-xs hover:scale-110 transition-transform"
                        title="Hide Mascot"
                    >
                        👻
                    </button>
                </div>
            </motion.div>
        </>
    );
};

export default FloatingBoxy;
