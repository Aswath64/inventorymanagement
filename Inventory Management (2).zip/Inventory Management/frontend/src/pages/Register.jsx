import { useMemo, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '../context/AuthContext';
import { useMascot } from '../context/MascotContext';

export default function Register() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    address: '',
    role: 'CUSTOMER'
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const { register } = useAuth();
  const { setEmotion } = useMascot();
  const navigate = useNavigate();

  const passwordStrength = useMemo(() => {
    const val = formData.password;
    if (val.length < 6) return 'weak';
    const hasNum = /\d/.test(val);
    const hasSym = /[^A-Za-z0-9]/.test(val);
    const hasUpper = /[A-Z]/.test(val);
    const score = [hasNum, hasSym, hasUpper].filter(Boolean).length;
    if (val.length > 10 && score >= 2) return 'strong';
    if (score >= 1) return 'medium';
    return 'weak';
  }, [formData.password]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      setEmotion('confused');
      return;
    }

    setLoading(true);
    setEmotion('thinking');

    setTimeout(async () => {
      const result = await register(formData);
      setLoading(false);
      if (result.success) {
        setEmotion('happy');
        const user = JSON.parse(localStorage.getItem('user'));
        if (user.role === 'STAFF') {
          navigate('/staff/dashboard');
        } else {
          navigate('/');
        }
      } else {
        setError(result.error);
        setEmotion('sad');
      }
    }, 800);
  };

  return (
    <div className="min-h-screen flex bg-pop-bg">
      {/* Left Side */}
      <div className="hidden lg:flex w-1/2 bg-pop-secondary items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-warehouse-grid opacity-20"></div>
        <div className="relative z-10 text-center p-12">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', bounce: 0.5 }}
            className="mb-8"
          >
            <h1 className="text-6xl font-heading font-bold text-white mb-4 drop-shadow-pop-lg">Join the<br />Squad! 🚀</h1>
            <p className="text-orange-100 text-xl font-medium">Start your inventory journey today.</p>
          </motion.div>
        </div>
      </div>

      {/* Right Side */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 relative overflow-y-auto max-h-screen">
        <div className="max-w-md w-full py-8">
          <div className="text-center mb-8 lg:text-left">
            <h2 className="text-4xl font-bold text-pop-text mb-2">Create Account</h2>
            <p className="text-pop-text-muted">Fill in your details to get started.</p>
          </div>

          {error && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="mb-6 rounded-2xl bg-red-50 border-2 border-red-100 p-4 flex items-center gap-3"
            >
              <span className="text-2xl">🚨</span>
              <p className="text-sm font-bold text-red-600">{error}</p>
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <label className="block text-sm font-bold text-pop-text">Full Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="w-full rounded-2xl border-2 border-slate-200 bg-white px-4 py-3 text-slate-900 placeholder-slate-400 focus:border-pop-secondary focus:ring-0 focus:shadow-pop-colored-orange transition-all duration-200"
                placeholder="John Doe"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-bold text-pop-text">Email Address</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                className="w-full rounded-2xl border-2 border-slate-200 bg-white px-4 py-3 text-slate-900 placeholder-slate-400 focus:border-pop-secondary focus:ring-0 focus:shadow-pop-colored-orange transition-all duration-200"
                placeholder="you@example.com"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="block text-sm font-bold text-pop-text">Password</label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={formData.password}
                    onFocus={() => setEmotion('shy')}
                    onBlur={() => setEmotion('idle')}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    required
                    className="w-full rounded-2xl border-2 border-slate-200 bg-white px-4 py-3 pr-10 text-slate-900 placeholder-slate-400 focus:border-pop-secondary focus:ring-0 focus:shadow-pop-colored-orange transition-all duration-200"
                    placeholder="••••••"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-pop-secondary font-bold text-xs"
                  >
                    {showPassword ? 'Hide' : 'Show'}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-bold text-pop-text">Confirm</label>
                <div className="relative">
                  <input
                    type={showConfirm ? 'text' : 'password'}
                    value={formData.confirmPassword}
                    onFocus={() => setEmotion('shy')}
                    onBlur={() => setEmotion('idle')}
                    onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                    required
                    className="w-full rounded-2xl border-2 border-slate-200 bg-white px-4 py-3 pr-10 text-slate-900 placeholder-slate-400 focus:border-pop-secondary focus:ring-0 focus:shadow-pop-colored-orange transition-all duration-200"
                    placeholder="••••••"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirm((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-pop-secondary font-bold text-xs"
                  >
                    {showConfirm ? 'Hide' : 'Show'}
                  </button>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-bold text-pop-text">Account Type</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, role: 'CUSTOMER' })}
                  className={`px-4 py-3 rounded-2xl border-2 transition-all font-bold ${formData.role === 'CUSTOMER'
                      ? 'border-pop-secondary bg-orange-50 text-pop-secondary shadow-pop-colored-orange'
                      : 'border-slate-200 bg-white text-slate-500 hover:border-slate-300'
                    }`}
                >
                  🛒 Customer
                </button>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, role: 'STAFF' })}
                  className={`px-4 py-3 rounded-2xl border-2 transition-all font-bold ${formData.role === 'STAFF'
                      ? 'border-pop-secondary bg-orange-50 text-pop-secondary shadow-pop-colored-orange'
                      : 'border-slate-200 bg-white text-slate-500 hover:border-slate-300'
                    }`}
                >
                  👔 Staff
                </button>
              </div>
            </div>

            <motion.button
              type="submit"
              disabled={loading}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full rounded-2xl bg-pop-secondary px-6 py-4 text-white font-bold text-lg shadow-pop-colored-orange hover:shadow-none hover:translate-y-[2px] disabled:opacity-50 disabled:cursor-not-allowed transition-all mt-4"
            >
              {loading ? 'Creating...' : 'Create Account'}
            </motion.button>
          </form>

          <div className="mt-8 text-center lg:text-left text-sm font-medium text-slate-500">
            Already have an account? <Link to="/login" className="text-pop-secondary hover:underline">Sign In</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
