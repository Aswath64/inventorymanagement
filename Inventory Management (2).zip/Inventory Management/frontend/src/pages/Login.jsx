import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '../context/AuthContext';
import { useMascot } from '../context/MascotContext';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const { login } = useAuth();
  const { setEmotion } = useMascot();
  const navigate = useNavigate();

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    setEmotion('thinking');

    setTimeout(async () => {
      const result = await login(email, password);
      setLoading(false);
      if (result.success) {
        setEmotion('happy');
        const user = JSON.parse(localStorage.getItem('user'));
        if (user.role === 'ADMIN') {
          navigate('/admin/dashboard');
        } else if (user.role === 'STAFF') {
          navigate('/staff/dashboard');
        } else {
          navigate('/');
        }
      } else {
        setError(result.error);
        setEmotion('sad');
      }
    }, 800);
  };

  return (
    <div className="min-h-screen flex bg-pop-bg">
      {/* Left Side - Mascot & Branding (Hidden on mobile) */}
      <div className="hidden lg:flex w-1/2 bg-pop-primary items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-warehouse-grid opacity-20"></div>
        <div className="relative z-10 text-center p-12">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', bounce: 0.5 }}
            className="mb-8"
          >
            <h1 className="text-6xl font-heading font-bold text-white mb-4 drop-shadow-pop-lg">Inventory<span className="text-pop-secondary">360</span></h1>
            <p className="text-blue-100 text-xl font-medium">Manage your stock with personality.</p>
          </motion.div>
        </div>
      </div>

      {/* Right Side - Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 relative">
        <div className="max-w-md w-full">
          <div className="text-center mb-10 lg:text-left">
            <h2 className="text-4xl font-bold text-pop-text mb-2">Welcome Back! 👋</h2>
            <p className="text-pop-text-muted">Enter your details to access your workspace.</p>
          </div>

          {error && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="mb-6 rounded-2xl bg-red-50 border-2 border-red-100 p-4 flex items-center gap-3"
            >
              <span className="text-2xl">🚨</span>
              <p className="text-sm font-bold text-red-600">{error}</p>
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="block text-sm font-bold text-pop-text">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full rounded-2xl border-2 border-slate-200 bg-white px-4 py-4 text-slate-900 placeholder-slate-400 focus:border-pop-primary focus:ring-0 focus:shadow-pop-colored-blue transition-all duration-200"
                placeholder="name@company.com"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-bold text-pop-text">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={handlePasswordChange}
                  onFocus={() => setEmotion('shy')}
                  onBlur={() => setEmotion('idle')}
                  required
                  className="w-full rounded-2xl border-2 border-slate-200 bg-white px-4 py-4 pr-12 text-slate-900 placeholder-slate-400 focus:border-pop-primary focus:ring-0 focus:shadow-pop-colored-blue transition-all duration-200"
                  placeholder="Your secret password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-pop-primary transition-colors font-bold"
                >
                  {showPassword ? 'Hide' : 'Show'}
                </button>
              </div>
            </div>

            <motion.button
              type="submit"
              disabled={loading}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full rounded-2xl bg-pop-primary px-6 py-4 text-white font-bold text-lg shadow-pop-colored-blue hover:shadow-none hover:translate-y-[2px] disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {loading ? 'Processing...' : 'Sign In'}
            </motion.button>
          </form>

          <div className="mt-8 text-center lg:text-left text-sm font-medium text-slate-500">
            New here? <Link to="/register" className="text-pop-primary hover:underline">Create an account</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
