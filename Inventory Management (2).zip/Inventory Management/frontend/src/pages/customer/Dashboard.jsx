import { useEffect, useState, useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Link } from 'react-router-dom';
import api from '../../utils/api';
import { useMascot } from '../../context/MascotContext';
import EmptyState from '../../components/EmptyState';

const SkeletonCard = () => (
  <div className="rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-6 shadow-pop animate-pulse">
    <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-1/3 mb-4"></div>
    <div className="h-8 bg-slate-300 dark:bg-slate-600 rounded w-1/2"></div>
  </div>
);

export default function CustomerDashboard() {
  const [dashboard, setDashboard] = useState(null);
  const [loading, setLoading] = useState(true);
  const { lookAt } = useMascot();
  const containerRef = useRef(null);

  // Less aggressive parallax for solid UI
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end start'],
  });
  const headerY = useTransform(scrollYProgress, [0, 1], [0, -20]);

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    try {
      const response = await api.get('/customer/dashboard');
      setDashboard(response.data);
    } catch (error) {
      console.error('Failed to fetch dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    {
      label: 'Total Orders',
      value: dashboard?.totalOrders || 0,
      color: 'bg-blue-500', // Solid high contrast
      shadow: 'shadow-pop-colored-blue',
      icon: '📦',
      link: '/orders',
      borderColor: 'border-blue-600',
    },
    {
      label: 'Wishlist',
      value: dashboard?.wishlistCount || 0,
      color: 'bg-emerald-500',
      shadow: 'shadow-pop-colored-orange', // Mix it up
      icon: '❤️',
      link: '/wishlist',
      borderColor: 'border-emerald-600',
    },
    {
      label: 'Member Since',
      value: dashboard?.profile?.createdAt
        ? new Date(dashboard.profile.createdAt).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
        : new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
      color: 'bg-indigo-500',
      shadow: 'shadow-pop-colored-blue',
      icon: '⭐',
      borderColor: 'border-indigo-600',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.08, delayChildren: 0.1 },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20, scale: 0.95 },
    visible: {
      opacity: 1, y: 0, scale: 1,
      transition: { type: 'spring', stiffness: 100, damping: 15 },
    },
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-pop-bg p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          <div className="h-20 bg-slate-200 dark:bg-slate-800 rounded-2xl w-full animate-pulse"></div>
          <div className="grid gap-6 md:grid-cols-3">
            <SkeletonCard /><SkeletonCard /><SkeletonCard />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div ref={containerRef} className="min-h-screen bg-pop-bg">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12 relative z-10">

        {/* Header Section */}
        <motion.div style={{ y: headerY }} className="mb-12">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-8 border-2 border-slate-900 shadow-pop-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-300 rounded-full blur-3xl opacity-20 -mr-10 -mt-10"></div>

            <div className="relative z-10">
              <p className="text-sm font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1">Welcome back</p>
              <h1 className="text-4xl lg:text-6xl font-heading font-bold text-slate-900 dark:text-white mb-2">
                {dashboard?.profile?.name || 'Customer'}
              </h1>
              <p className="text-xl text-slate-600 dark:text-slate-300 font-medium">
                Ready to check your inventory status?
              </p>
            </div>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid gap-6 md:grid-cols-3 mb-12"
        >
          {statCards.map((card, idx) => {
            const CardContent = (
              <motion.div
                variants={cardVariants}
                whileHover={{ y: -4, rotate: -1 }}
                whileTap={{ scale: 0.98 }}
                onMouseEnter={() => lookAt(window.innerWidth / 2 + (idx - 1) * 200, window.innerHeight / 2)}
                className={`
                   relative overflow-hidden rounded-2xl p-6 text-white cursor-pointer transition-all duration-200
                   ${card.color} ${card.shadow} border-2 ${card.borderColor}
                 `}
              >
                <div className="flex justify-between items-start mb-4">
                  <span className="text-4xl filter drop-shadow-md">{card.icon}</span>
                  <div className="w-8 h-8 rounded-full bg-white/20 border-2 border-white/30 flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                  </div>
                </div>
                <div>
                  <p className="text-blue-100 font-bold uppercase text-xs tracking-wider mb-1">{card.label}</p>
                  <p className="text-3xl font-heading font-bold">{card.value}</p>
                </div>
              </motion.div>
            );

            return card.link ? <Link key={card.label} to={card.link}>{CardContent}</Link> : <div key={card.label}>{CardContent}</div>;
          })}
        </motion.div>

        {/* Recent Orders Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white dark:bg-slate-800 rounded-3xl border-2 border-slate-200 dark:border-slate-700 shadow-pop p-8"
        >
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span>🛍️</span> Recent Orders
            </h2>
            {dashboard?.recentOrders?.length > 0 && (
              <Link to="/orders" className="bg-slate-100 dark:bg-slate-700 text-slate-900 dark:text-white px-4 py-2 rounded-xl font-bold hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
                View All
              </Link>
            )}
          </div>

          {dashboard?.recentOrders?.length > 0 ? (
            <div className="space-y-4">
              {dashboard.recentOrders.map((order, idx) => (
                <motion.div
                  key={order.id}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: idx * 0.1 }}
                  className="flex items-center justify-between p-4 rounded-xl border-2 border-slate-100 dark:border-slate-700 hover:border-blue-200 dark:hover:border-blue-800 hover:bg-blue-50 dark:hover:bg-blue-900/10 transition-colors group cursor-pointer"
                >
                  <div>
                    <p className="font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">Order #{order.id}</p>
                    <p className="text-slate-500 font-medium">${order.totalAmount?.toFixed(2)}</p>
                  </div>
                  <span className={`
                       px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide border
                       ${order.status === 'DELIVERED' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' :
                      order.status === 'CANCELLED' ? 'bg-red-100 text-red-700 border-red-200' :
                        'bg-amber-100 text-amber-700 border-amber-200'}
                     `}>
                    {order.status}
                  </span>
                </motion.div>
              ))}
            </div>
          ) : (
            <EmptyState
              icon="📦"
              title="No orders found!"
              description="It looks like you haven't bought anything yet. Go buy stuff!"
              emotion="confused"
              showBoxy={true}
              action={
                <Link to="/products" className="inline-block mt-4 bg-blue-600 text-white font-bold py-3 px-6 rounded-xl hover:bg-blue-700 shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all">
                  Start Shopping
                </Link>
              }
            />
          )}
        </motion.div>

      </div>
    </div>
  );
}
