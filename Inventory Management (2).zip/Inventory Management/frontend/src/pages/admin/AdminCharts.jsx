import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { motion } from 'framer-motion';

const cardStyle = "rounded-2xl bg-white/80 dark:bg-slate-800/80 backdrop-blur-xl border border-slate-200/50 dark:border-slate-700/50 p-6 shadow-lg h-[400px]";

// --- Mock Data (Generate fun looking data) ---
const salesData = [
    { name: 'Mon', sales: 4000, amt: 2400 },
    { name: 'Tue', sales: 3000, amt: 1398 },
    { name: 'Wed', sales: 2000, amt: 9800 },
    { name: 'Thu', sales: 2780, amt: 3908 },
    { name: 'Fri', sales: 1890, amt: 4800 },
    { name: 'Sat', sales: 2390, amt: 3800 },
    { name: 'Sun', sales: 3490, amt: 4300 },
];

const productData = [
    { name: 'Electronics', value: 400 },
    { name: 'Clothing', value: 300 },
    { name: 'Home', value: 300 },
    { name: 'Toys', value: 200 },
];

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff8042'];

const usersData = [
    { name: 'Jan', users: 100 },
    { name: 'Feb', users: 200 },
    { name: 'Mar', users: 350 },
    { name: 'Apr', users: 500 },
    { name: 'May', users: 450 },
    { name: 'Jun', users: 700 },
];

export const SalesChart = () => (
    <motion.div
        className={cardStyle}
        whileHover={{ y: -5 }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
    >
        <h3 className="text-xl font-bold mb-4 text-slate-800 dark:text-white">Weekly Sales</h3>
        <ResponsiveContainer width="100%" height="90%">
            <AreaChart data={salesData}>
                <defs>
                    <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8} />
                        <stop offset="95%" stopColor="#8884d8" stopOpacity={0} />
                    </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis dataKey="name" stroke="#8884d8" />
                <YAxis stroke="#8884d8" />
                <Tooltip
                    contentStyle={{ backgroundColor: 'rgba(255, 255, 255, 0.8)', borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }}
                />
                <Area type="monotone" dataKey="sales" stroke="#8884d8" fillOpacity={1} fill="url(#colorSales)" />
            </AreaChart>
        </ResponsiveContainer>
    </motion.div>
);

export const ProductsChart = () => (
    <motion.div
        className={cardStyle}
        whileHover={{ y: -5 }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
    >
        <h3 className="text-xl font-bold mb-4 text-slate-800 dark:text-white">Product Categories</h3>
        <ResponsiveContainer width="100%" height="90%">
            <PieChart>
                <Pie
                    data={productData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                    label
                >
                    {productData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                </Pie>
                <Tooltip />
            </PieChart>
        </ResponsiveContainer>
    </motion.div>
);

export const UsersChart = () => (
    <motion.div
        className={cardStyle}
        whileHover={{ y: -5 }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
    >
        <h3 className="text-xl font-bold mb-4 text-slate-800 dark:text-white">New Users Growth</h3>
        <ResponsiveContainer width="100%" height="90%">
            <BarChart data={usersData}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis dataKey="name" stroke="#82ca9d" />
                <YAxis stroke="#82ca9d" />
                <Tooltip cursor={{ fill: 'transparent' }} />
                <Bar dataKey="users" fill="#82ca9d" radius={[10, 10, 0, 0]} />
            </BarChart>
        </ResponsiveContainer>
    </motion.div>
);
