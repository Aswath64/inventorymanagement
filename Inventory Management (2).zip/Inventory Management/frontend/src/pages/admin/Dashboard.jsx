import { useEffect, useState } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';
import api from '../../utils/api';

// Skeleton loader component
const SkeletonCard = () => (
  <div className="rounded-2xl bg-white/60 dark:bg-slate-800/60 backdrop-blur-xl border border-slate-200/50 dark:border-slate-700/50 p-6 shadow-lg animate-pulse">
    <div className="h-4 bg-slate-300 dark:bg-slate-700 rounded w-1/3 mb-4"></div>
    <div className="h-8 bg-slate-300 dark:bg-slate-700 rounded w-1/2"></div>
  </div>
);

const SkeletonListItem = () => (
  <div className="rounded-xl bg-slate-100/50 dark:bg-slate-700/30 border border-slate-200/30 dark:border-slate-600/30 p-4 animate-pulse">
    <div className="h-4 bg-slate-300 dark:bg-slate-600 rounded w-2/3 mb-2"></div>
    <div className="h-3 bg-slate-300 dark:bg-slate-600 rounded w-1/3"></div>
  </div>
);

import EmptyState from '../../components/EmptyState';
import { SalesChart, ProductsChart, UsersChart } from './AdminCharts'; // Import Charts

export default function AdminDashboard() {
  const [dashboard, setDashboard] = useState(null);
  const [loading, setLoading] = useState(true);
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end start'],
  });

  // Parallax transform for background elements
  const backgroundY = useTransform(scrollYProgress, [0, 1], [0, -100]);
  const contentY = useTransform(scrollYProgress, [0, 1], [0, -30]);

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    try {
      const response = await api.get('/admin/dashboard');
      setDashboard(response.data);
    } catch (error) {
      console.error('Failed to fetch dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  // Card data with icons
  const statCards = [
    {
      label: 'Total Products',
      value: dashboard?.totalProducts || 0,
      gradient: 'from-blue-500 via-blue-600 to-indigo-600',
      icon: '📦',
      bgPattern: 'radial-gradient(circle at 20% 50%, rgba(59, 130, 246, 0.3), transparent 50%)',
    },
    {
      label: 'Total Customers',
      value: dashboard?.totalCustomers || 0,
      gradient: 'from-emerald-500 via-emerald-600 to-teal-600',
      icon: '👥',
      bgPattern: 'radial-gradient(circle at 20% 50%, rgba(16, 185, 129, 0.3), transparent 50%)',
    },
    {
      label: 'Total Staff',
      value: dashboard?.totalStaff || 0,
      gradient: 'from-amber-500 via-amber-600 to-orange-600',
      icon: '👔',
      bgPattern: 'radial-gradient(circle at 20% 50%, rgba(245, 158, 11, 0.3), transparent 50%)',
    },
    {
      label: 'Total Sales',
      value: `$${dashboard?.totalSales?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || '0.00'}`,
      gradient: 'from-purple-500 via-purple-600 to-pink-600',
      icon: '💰',
      bgPattern: 'radial-gradient(circle at 20% 50%, rgba(168, 85, 247, 0.3), transparent 50%)',
    },
  ];

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08,
        delayChildren: 0.1,
      },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20, scale: 0.95 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
        damping: 15,
        duration: 0.4,
      },
    },
  };

  const listItemVariants = {
    hidden: { opacity: 0, x: -10 },
    visible: (i) => ({
      opacity: 1,
      x: 0,
      transition: {
        delay: i * 0.05,
        duration: 0.3,
      },
    }),
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
          <div className="mb-8">
            <div className="h-10 bg-slate-300 dark:bg-slate-700 rounded-xl w-64 animate-pulse"></div>
          </div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
            {[1, 2, 3, 4].map((i) => (
              <SkeletonCard key={i} />
            ))}
          </div>
          <div className="grid gap-6 md:grid-cols-2">
            <div className="rounded-2xl bg-white/60 dark:bg-slate-800/60 backdrop-blur-xl border border-slate-200/50 dark:border-slate-700/50 p-6 shadow-lg">
              <div className="h-6 bg-slate-300 dark:bg-slate-700 rounded w-48 mb-6 animate-pulse"></div>
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <SkeletonListItem key={i} />
                ))}
              </div>
            </div>
            <div className="rounded-2xl bg-white/60 dark:bg-slate-800/60 backdrop-blur-xl border border-slate-200/50 dark:border-slate-700/50 p-6 shadow-lg">
              <div className="h-6 bg-slate-300 dark:bg-slate-700 rounded w-48 mb-6 animate-pulse"></div>
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <SkeletonListItem key={i} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900"
      style={{ scrollBehavior: 'smooth' }}
    >
      {/* Parallax background decoration */}
      <motion.div
        style={{ y: backgroundY }}
        className="fixed inset-0 pointer-events-none overflow-hidden"
        aria-hidden="true"
      >
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-400/10 dark:bg-blue-500/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-400/10 dark:bg-purple-500/5 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-emerald-400/10 dark:bg-emerald-500/5 rounded-full blur-3xl"></div>
      </motion.div>

      {/* Main content with parallax */}
      <motion.div style={{ y: contentY }} className="relative z-10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
          {/* Page Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
            className="mb-8 lg:mb-12"
          >
            <h1 className="text-4xl lg:text-5xl font-bold text-slate-900 dark:text-white mb-2 tracking-tight">
              Admin Dashboard
            </h1>
            <p className="text-slate-600 dark:text-slate-400 text-base lg:text-lg">
              Overview of your inventory management system
            </p>
          </motion.div>

          {/* Stats Cards Grid */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid gap-4 sm:gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8 lg:mb-12"
          >
            {statCards.map((card, idx) => (
              <motion.div
                key={card.label}
                variants={cardVariants}
                whileHover={{ scale: 1.02, y: -4 }}
                whileTap={{ scale: 0.98 }}
                className={`group relative overflow-hidden rounded-2xl bg-gradient-to-br ${card.gradient} p-6 text-white shadow-xl shadow-black/10 dark:shadow-black/20 cursor-pointer transition-all duration-300`}
              >

                {/* Content */}
                <div className="relative z-10">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-3xl opacity-90 group-hover:scale-110 transition-transform duration-300">
                      {card.icon}
                    </span>
                    <div className="w-2 h-2 rounded-full bg-white/40 group-hover:bg-white/60 transition-colors"></div>
                  </div>
                  <p className="text-xs sm:text-sm font-medium uppercase tracking-wider opacity-90 mb-2">
                    {card.label}
                  </p>
                  <p className="text-2xl sm:text-3xl font-bold tracking-tight">
                    {card.value}
                  </p>
                </div>

                {/* Shine effect on hover */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* Analytics Charts */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-8 lg:mb-12"
          >
            <div className="lg:col-span-2">
              <SalesChart />
            </div>
            <div className="lg:col-span-1">
              <ProductsChart />
            </div>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid gap-6 md:grid-cols-1 lg:grid-cols-3 mb-8 lg:mb-12"
          >
            <div className="lg:col-span-3">
              <UsersChart />
            </div>
          </motion.div>

          {/* Content Cards Grid */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid gap-6 md:grid-cols-2"
          >
            {/* Low Stock Products Card */}
            <motion.div
              variants={cardVariants}
              className="rounded-2xl bg-white/80 dark:bg-slate-800/80 backdrop-blur-xl border border-slate-200/50 dark:border-slate-700/50 p-6 lg:p-8 shadow-lg hover:shadow-xl transition-shadow duration-300"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl lg:text-2xl font-semibold text-slate-900 dark:text-white">
                  Low Stock Products
                </h2>
                <div className="w-10 h-10 rounded-xl bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
                  <span className="text-xl">⚠️</span>
                </div>
              </div>

              {dashboard?.lowStockProducts && dashboard.lowStockProducts.length > 0 ? (
                <div className="space-y-3">
                  {dashboard.lowStockProducts.map((product, idx) => (
                    <motion.div
                      key={product.id}
                      custom={idx}
                      variants={listItemVariants}
                      initial="hidden"
                      animate="visible"
                      whileHover={{ x: 4, scale: 1.02, y: -2 }}
                      className="rounded-2xl bg-gradient-to-r from-cartoon-red-50/80 to-cartoon-yellow-50/80 dark:from-cartoon-red-900/20 dark:to-cartoon-yellow-900/20 border-2 border-cartoon-red-200/60 dark:border-cartoon-red-800/40 p-4 cursor-pointer transition-all duration-200 shadow-sticker hover:shadow-sticker-lg"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-slate-900 dark:text-white truncate mb-1">
                            {product.name}
                          </p>
                          <div className="flex items-center gap-2">
                            <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-bold bg-cartoon-red-100 dark:bg-cartoon-red-900/40 text-cartoon-red-700 dark:text-cartoon-red-300 border-2 border-cartoon-red-300 dark:border-cartoon-red-700 shadow-sticker">
                              Stock: {product.stock}
                            </span>
                          </div>
                        </div>
                        <div className="ml-4 flex-shrink-0">
                          <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <EmptyState
                  title="All products well stocked!"
                  description="Great job! All your inventory is at healthy levels. Boxy is happy!"
                  emotion="happy"
                  size="md"
                  showBoxy={true}
                />
              )}
            </motion.div>

            {/* Most Sold Products Card */}
            <motion.div
              variants={cardVariants}
              className="rounded-2xl bg-white/80 dark:bg-slate-800/80 backdrop-blur-xl border border-slate-200/50 dark:border-slate-700/50 p-6 lg:p-8 shadow-lg hover:shadow-xl transition-shadow duration-300"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl lg:text-2xl font-semibold text-slate-900 dark:text-white">
                  Most Sold Products
                </h2>
                <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                  <span className="text-xl">📈</span>
                </div>
              </div>

              {dashboard?.mostSoldProducts && dashboard.mostSoldProducts.length > 0 ? (
                <div className="space-y-3">
                  {dashboard.mostSoldProducts.map((product, idx) => (
                    <motion.div
                      key={product.id}
                      custom={idx}
                      variants={listItemVariants}
                      initial="hidden"
                      animate="visible"
                      whileHover={{ x: 4, scale: 1.02, y: -2 }}
                      className="rounded-2xl bg-gradient-to-r from-slate-50/80 to-slate-100/80 dark:from-slate-700/30 dark:to-slate-600/30 border-2 border-slate-200/60 dark:border-slate-600/40 p-4 cursor-pointer transition-all duration-200 shadow-sticker hover:shadow-sticker-lg"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-slate-900 dark:text-white truncate mb-1 text-base">
                            {product.name}
                          </p>
                          <p className="text-sm text-slate-600 dark:text-slate-400">
                            Price: <span className="font-bold text-cartoon-green-600 dark:text-cartoon-green-400">${product.price}</span>
                          </p>
                        </div>
                        <div className="ml-4 flex-shrink-0">
                          <motion.div
                            whileHover={{ scale: 1.1, rotate: 5 }}
                            className="w-10 h-10 rounded-2xl bg-gradient-to-br from-cartoon-green-400 to-cartoon-green-600 dark:from-cartoon-green-600 dark:to-cartoon-green-800 flex items-center justify-center shadow-sticker border-2 border-cartoon-green-300 dark:border-cartoon-green-700"
                          >
                            <span className="text-white text-sm font-bold">#{idx + 1}</span>
                          </motion.div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <EmptyState
                  title="No sales data yet"
                  description="Sales data will appear here once products are sold. Boxy is waiting for your first sale!"
                  emotion="idle"
                  size="md"
                  showBoxy={true}
                />
              )}
            </motion.div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
