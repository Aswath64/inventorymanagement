class SoundManager {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.isMuted = false;
    this.lastPlayed = {}; // For cooldown tracks
    this.cooldowns = {
      pop: 100,
      hover: 50,
      chat: 200,
      success: 500,
      error: 500,
    };
  }

  init() {
    if (this.ctx) return;
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    this.ctx = new AudioContext();
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = 0.3; // Default volume
    this.masterGain.connect(this.ctx.destination);
  }

  setMute(mute) {
    this.isMuted = mute;
    if (this.masterGain) {
      this.masterGain.gain.setValueAtTime(mute ? 0 : 0.3, this.ctx.currentTime);
    }
    // Persist preference
    localStorage.setItem('mascot_muted', mute);
  }

  playTone(freq, type, duration, startTime = 0) {
    if (this.isMuted || !this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime + startTime);

    gain.gain.setValueAtTime(0.1, this.ctx.currentTime + startTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + startTime + duration);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(this.ctx.currentTime + startTime);
    osc.stop(this.ctx.currentTime + startTime + duration);
  }

  play(soundName) {
    if (this.isMuted) return;
    this.init(); // Ensure context is ready (user interaction required normally)

    // Cooldown check
    const now = Date.now();
    if (
      this.lastPlayed[soundName] &&
      now - this.lastPlayed[soundName] < (this.cooldowns[soundName] || 50)
    ) {
      return;
    }
    this.lastPlayed[soundName] = now;

    // Sound Synthesis Logic
    switch (soundName) {
      case 'pop':
        // Quick high-pitch sine 'bloop'
        this.playTone(600, 'sine', 0.1);
        break;
      case 'hover':
        // Very subtle click
        this.playTone(400, 'triangle', 0.05);
        break;
      case 'success':
        // Happy major arpeggio
        this.playTone(440, 'sine', 0.1, 0);       // A4
        this.playTone(554.37, 'sine', 0.1, 0.1);  // C#5
        this.playTone(659.25, 'sine', 0.2, 0.2);  // E5
        break;
      case 'error':
        // Low descending buzz
        this.playTone(150, 'sawtooth', 0.2, 0);
        this.playTone(100, 'sawtooth', 0.3, 0.1);
        break;
      case 'levelUp':
        // Victory fanfare snippet
        this.playTone(523.25, 'square', 0.1, 0);   // C5
        this.playTone(659.25, 'square', 0.1, 0.1); // E5
        this.playTone(783.99, 'square', 0.1, 0.2); // G5
        this.playTone(1046.50, 'square', 0.4, 0.3);// C6
        break;
      case 'click':
        // Short high blip
        this.playTone(800, 'sine', 0.05);
        break;
      case 'transition':
        // Ascending slide
        this.playTone(300, 'triangle', 0.2);
        break;
      case 'whoosh':
        // Noise-like swoosh (simulated with slide)
        this.playTone(200, 'sawtooth', 0.2);
        break;
      default:
        break;
    }
  }
}

export const soundManager = new SoundManager();
export default soundManager;
