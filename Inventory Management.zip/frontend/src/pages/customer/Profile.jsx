export { default } from '../shared/ProfileSettings';

