import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import SoundToggle from './SoundToggle';
import soundManager from '../utils/soundUtils';

const navVariants = {
  hidden: { y: -20, opacity: 0 },
  visible: { y: 0, opacity: 1, transition: { duration: 0.4 } },
};

export default function Navbar() {
  const { user, logout, isAdmin, isStaff, isCustomer } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();

  const handleLogout = () => {
    soundManager.playTransition();
    logout();
    navigate('/login');
  };

  const handleLinkClick = () => {
    soundManager.playClick();
  };

  const links = [];
  if (user) {
    if (isCustomer) {
      links.push(
        { to: '/products', label: 'Products' },
        { to: '/cart', label: 'Cart' },
        { to: '/wishlist', label: 'Wishlist' },
        { to: '/orders', label: 'Orders' },
      );
    }
    if (isAdmin) {
      links.push(
        { to: '/admin/dashboard', label: 'Admin' },
        { to: '/admin/categories', label: 'Categories' },
        { to: '/admin/products', label: 'Inventory' },
        { to: '/admin/orders', label: 'Orders' },
        { to: '/admin/users', label: 'Users' },
        { to: '/admin/reports', label: 'Reports' },
      );
    } else if (isStaff) {
      links.push(
        { to: '/staff/dashboard', label: 'Staff' },
        { to: '/staff/orders', label: 'Tasks' },
        { to: '/staff/reports', label: 'Reports' },
      );
    }
    links.push({ to: '/settings', label: 'Profile & Settings' });
  }

  return (
    <motion.nav
      className="sticky top-0 z-40 backdrop-blur-xl bg-white/70 dark:bg-slate-900/70 border-b border-white/10"
      variants={navVariants}
      initial="hidden"
      animate="visible"
    >
      <div className="container mx-auto flex flex-wrap items-center justify-between gap-4 px-4 py-3">
        <motion.div whileHover={{ scale: 1.02 }} className="text-2xl font-semibold text-slate-900 dark:text-white">
          <Link to="/">Inventory<span className="text-blue-500">360</span></Link>
        </motion.div>

        <div className="flex flex-wrap items-center gap-4 text-sm">
          {links.map(link => (
            <motion.div key={link.to} whileHover={{ y: -2, scale: 1.05 }}>
              <Link 
                className="text-slate-600 dark:text-slate-200 hover:text-cartoon-blue-500 font-medium transition-colors" 
                to={link.to}
                onClick={handleLinkClick}
              >
                {link.label}
              </Link>
            </motion.div>
          ))}
          {user && (
            <>
              <SoundToggle />
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  soundManager.playClick();
                  toggleTheme();
                }}
                className="rounded-full border-2 border-slate-300 dark:border-slate-600 px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors shadow-sticker"
              >
                {theme === 'light' ? '🌙 Dark' : '☀️ Light'}
              </motion.button>
              <motion.div whileHover={{ scale: 1.02 }} className="flex items-center gap-2">
                <span className="text-slate-700 dark:text-slate-300 font-medium">{user.name}</span>
                <motion.button
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleLogout}
                  className="rounded-full bg-gradient-to-r from-cartoon-red-500 to-red-600 px-4 py-1.5 text-white text-xs font-bold shadow-sticker-lg hover:shadow-floating transition-all"
                >
                  Logout
                </motion.button>
              </motion.div>
            </>
          )}
        </div>
      </div>
    </motion.nav>
  );
}

