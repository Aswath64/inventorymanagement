/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      height: {
        'cratey-md': '5.75rem', // palm-sized on tablet
        'cratey-lg': '7rem',    // larger than hand on desktop
      },
      colors: {
        // Brand / cartoon-premium palette
        brand: {
          ink: '#111827',
          soft: '#4B5563',
          bg: '#0F172A',
          primary: {
            DEFAULT: '#6366F1',
            soft: '#A5B4FC',
            strong: '#4F46E5',
          },
          secondary: {
            DEFAULT: '#F97316',
            soft: '#FED7AA',
            strong: '#EA580C',
          },
          accent: {
            mint: '#2DD4BF',
            lemon: '#FACC15',
            bubblegum: '#FB7185',
            sky: '#38BDF8',
          },
          surface: {
            DEFAULT: '#0B1220',
            alt: '#020617',
            raised: '#111827',
            muted: '#1F2937',
          },
          border: {
            soft: '#1F2933',
            strong: '#4B5563',
            accent: '#A5B4FC',
          },
          status: {
            inStock: '#22C55E',     // emerald-500
            lowStock: '#FACC15',    // yellow-400
            outStock: '#EF4444',    // red-500
            pending: '#F59E0B',     // amber-500
            pendingAlt: '#3B82F6',  // blue-500
            cancelled: '#9CA3AF',   // gray-400
            cancelledAlt: '#FB7185' // rose-400
          }
        },
        // Original colors (kept for compatibility)
        primary: {
          50:  '#eff6ff',
          100: '#dbeafe',
          200: '#bfdbfe',
          300: '#93c5fd',
          400: '#60a5fa',
          500: '#3b82f6',
          600: '#2563eb',
          700: '#1d4ed8',
          800: '#1e40af',
          900: '#1e3a8a',
        },
        success: {
          50: '#ecfdf5',
          100: '#d1fae5',
          200: '#a7f3d0',
          300: '#6ee7b7',
          400: '#34d399',
          500: '#10b981',
          600: '#059669',
          700: '#047857',
          800: '#065f46',
          900: '#064e3b',
        },
        danger: {
          50: '#fef2f2',
          100: '#fee2e2',
          200: '#fecaca',
          300: '#fca5a5',
          400: '#f87171',
          500: '#ef4444',
          600: '#dc2626',
          700: '#b91c1c',
          800: '#991b1b',
          900: '#7f1d1d',
        },
        // Cartoon-friendly color system
        'cartoon-blue': {
          50: '#e0f2fe',
          100: '#bae6fd',
          200: '#7dd3fc',
          300: '#38bdf8',
          400: '#0ea5e9',
          500: '#0284c7',
          600: '#0369a1',
          700: '#075985',
          800: '#0c4a6e',
          900: '#082f49',
        },
        'cartoon-green': {
          50: '#f0fdf4',
          100: '#dcfce7',
          200: '#bbf7d0',
          300: '#86efac',
          400: '#4ade80',
          500: '#22c55e',
          600: '#16a34a',
          700: '#15803d',
          800: '#166534',
          900: '#14532d',
        },
        'cartoon-yellow': {
          50: '#fefce8',
          100: '#fef9c3',
          200: '#fef08a',
          300: '#fde047',
          400: '#facc15',
          500: '#eab308',
          600: '#ca8a04',
          700: '#a16207',
          800: '#854d0e',
          900: '#713f12',
        },
        'cartoon-red': {
          50: '#fef2f2',
          100: '#fee2e2',
          200: '#fecaca',
          300: '#fca5a5',
          400: '#f87171',
          500: '#ef4444',
          600: '#dc2626',
          700: '#b91c1c',
          800: '#991b1b',
          900: '#7f1d1d',
        },
        'cartoon-purple': {
          50: '#faf5ff',
          100: '#f3e8ff',
          200: '#e9d5ff',
          300: '#d8b4fe',
          400: '#c084fc',
          500: '#a855f7',
          600: '#9333ea',
          700: '#7e22ce',
          800: '#6b21a8',
          900: '#581c87',
        },
      },
      fontFamily: {
        'heading': ['"Fredoka"', 'Poppins', 'system-ui', 'sans-serif'],
        'body': ['Inter', 'system-ui', 'sans-serif'],
        'numeric': ['"DM Sans"', 'Inter', 'system-ui', 'sans-serif'],
      },
      borderRadius: {
        'btn': '9999px',
        'input': '9999px',
        'card': '1.75rem',
        'modal': '2.25rem',
        'image': '1.5rem',
        'chip': '9999px',
        'cartoon': '1.5rem', // legacy
        'bubble': '1rem',
      },
      height: {
        'cratey-md': '4.5rem',
        'cratey-lg': '5.5rem',
      },
      boxShadow: {
        card: '0 14px 40px rgba(15,23,42,0.7)',
        cardSoft: '0 12px 30px rgba(15,23,42,0.55)',
        hover: '0 18px 50px rgba(15,23,42,0.9)',
        modal: '0 30px 80px rgba(15,23,42,0.95)',
        sticker: '0 0 0 2px rgba(15,23,42,1), 0 10px 0 rgba(15,23,42,0.75)',
        'sticker-lg': '0 12px 24px rgba(0, 0, 0, 0.2)',
        'floating': '0 16px 32px rgba(0, 0, 0, 0.25)',
        'glow-blue': '0 0 20px rgba(14, 165, 233, 0.4)',
        'glow-green': '0 0 20px rgba(34, 197, 94, 0.4)',
        'glow-yellow': '0 0 20px rgba(234, 179, 8, 0.4)',
        'glow-red': '0 0 20px rgba(239, 68, 68, 0.4)',
        'cratey-base': '0 10px 30px rgba(15,23,42,0.25)',
        'cratey-strong': '0 16px 40px rgba(15,23,42,0.35)',
        'ground': '0 14px 40px rgba(0,0,0,0.30)',
      },
      backgroundImage: {
        'dashboard-gradient': 'radial-gradient(circle at top, #1D4ED8 0, #020617 45%, #020617 100%)',
        'analytics-gradient': 'radial-gradient(circle at 20% 0, #22C55E 0, transparent 50%), radial-gradient(circle at 80% 100%, #F97316 0, #020617 55%)',
        'highlight-gradient': 'linear-gradient(135deg, #A5B4FC 0%, #2DD4BF 50%, #FBBF24 100%)',
        'warehouse-dots': 'radial-gradient(circle, rgba(148,163,184,0.35) 1px, transparent 1px)',
        'warehouse-grid': 'linear-gradient(to right, rgba(148,163,184,0.12) 1px, transparent 1px), linear-gradient(to bottom, rgba(148,163,184,0.12) 1px, transparent 1px)',
      },
      backgroundSize: {
        'dots-sm': '12px 12px',
        'grid-md': '24px 24px',
      },
      animation: {
        'bounce-gentle': 'bounce-gentle 2s ease-in-out infinite',
        'float': 'float 3s ease-in-out infinite',
        'pulse-glow': 'pulse-glow 2s ease-in-out infinite',
        'shake': 'shake 0.4s ease-in-out',
        'pop-in': 'pop-in 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55)',
        'squash-stretch': 'squash-stretch 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55)',
        'page-in': 'page-in 260ms cubic-bezier(0.21,0.68,0.35,1)',
        'card-reveal': 'card-reveal 220ms ease-out',
        'btn-hover-subtle': 'btn-hover 150ms ease-out forwards',
        'btn-press': 'btn-press 140ms ease-out',
        'success-pop': 'success-pop 260ms cubic-bezier(0.16,1,0.3,1)',
        'error-shake': 'error-shake 220ms ease-in-out',
        'error-pulse': 'error-pulse 400ms ease-out',
        'idle-float': 'idle-float 3500ms ease-in-out infinite',
        'fade-slide-up': 'fade-slide-up 220ms ease-out',
        'bounce-soft': 'bounce-soft 400ms ease-out',
        'shake-soft': 'shake-soft 220ms ease-in-out',
        'periodic-float': 'periodic-float 4500ms ease-in-out infinite',
        'chart-draw-line': 'chart-draw-line 700ms ease-out forwards',
        'chart-pop-bar': 'chart-pop-bar 500ms ease-out forwards',
        'cratey-idle-desk': 'cratey-idle-desk 4200ms ease-in-out infinite',
        'cratey-lean-focus': 'cratey-lean-focus 200ms ease-out forwards',
        'cratey-hop': 'cratey-hop 320ms cubic-bezier(0.22,1,0.36,1)',
        'cratey-recoil': 'cratey-recoil 260ms ease-out',
        'cratey-cover': 'cratey-cover 220ms ease-out forwards',
        'cratey-stealth': 'cratey-stealth 200ms ease-out forwards',
        'cratey-sit-sleep': 'cratey-sit-sleep 1200ms ease-in-out infinite',
        'pal-lean': 'pal-lean 300ms ease-out forwards',
        'zip-zoom': 'zip-zoom 280ms ease-out',
        'ink-flash': 'ink-flash 220ms ease-out',
      },
      keyframes: {
        'bounce-gentle': {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-8px)' },
        },
        'float': {
          '0%, 100%': { transform: 'translateY(0) rotate(0deg)' },
          '50%': { transform: 'translateY(-12px) rotate(2deg)' },
        },
        'pulse-glow': {
          '0%, 100%': { boxShadow: '0 0 20px rgba(14, 165, 233, 0.4)' },
          '50%': { boxShadow: '0 0 30px rgba(14, 165, 233, 0.6)' },
        },
        'shake': {
          '0%, 100%': { transform: 'translateX(0)' },
          '10%, 30%, 50%, 70%, 90%': { transform: 'translateX(-8px)' },
          '20%, 40%, 60%, 80%': { transform: 'translateX(8px)' },
        },
        'pop-in': {
          '0%': { transform: 'scale(0.8)', opacity: '0' },
          '50%': { transform: 'scale(1.05)' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
        'squash-stretch': {
          '0%': { transform: 'scaleX(0.8) scaleY(1.2)', opacity: '0' },
          '50%': { transform: 'scaleX(1.1) scaleY(0.9)' },
          '100%': { transform: 'scaleX(1) scaleY(1)', opacity: '1' },
        },
        'page-in': {
          '0%': { opacity: '0', transform: 'translateY(12px) scale(0.98)' },
          '100%': { opacity: '1', transform: 'translateY(0) scale(1)' },
        },
        'card-reveal': {
          '0%': { opacity: '0', transform: 'translateY(10px) scale(0.98)' },
          '100%': { opacity: '1', transform: 'translateY(0) scale(1)' },
        },
        'btn-hover': {
          '0%': { transform: 'translateY(0)' },
          '100%': { transform: 'translateY(-2px)' },
        },
        'btn-press': {
          '0%': { transform: 'scale(1)' },
          '50%': { transform: 'scale(0.96)' },
          '100%': { transform: 'scale(1)' },
        },
        'success-pop': {
          '0%': { transform: 'scale(0.8)', opacity: '0' },
          '60%': { transform: 'scale(1.05)', opacity: '1' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
        'error-shake': {
          '0%, 100%': { transform: 'translateX(0)' },
          '20%': { transform: 'translateX(-4px)' },
          '40%': { transform: 'translateX(4px)' },
          '60%': { transform: 'translateX(-3px)' },
          '80%': { transform: 'translateX(3px)' },
        },
        'error-pulse': {
          '0%, 100%': { boxShadow: '0 0 0 0 rgba(248,113,113,0)' },
          '50%': { boxShadow: '0 0 0 6px rgba(248,113,113,0.3)' },
        },
        'idle-float': {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-6px)' },
        },
        'fade-slide-up': {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'bounce-soft': {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-3px)' },
        },
        'shake-soft': {
          '0%, 100%': { transform: 'translateX(0)' },
          '25%': { transform: 'translateX(-3px)' },
          '75%': { transform: 'translateX(3px)' },
        },
        'periodic-float': {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-4px)' },
        },
        'chart-draw-line': {
          '0%': { strokeDasharray: '1000', strokeDashoffset: '1000' },
          '100%': { strokeDashoffset: '0' },
        },
        'chart-pop-bar': {
          '0%': { transform: 'scaleY(0)', transformOrigin: 'bottom' },
          '100%': { transform: 'scaleY(1)', transformOrigin: 'bottom' },
        },
        'cratey-idle-desk': {
          '0%,100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-4px)' },
        },
        'cratey-lean-focus': {
          '0%': { transform: 'translateY(0) scale(1)' },
          '100%': { transform: 'translateY(-3px) scale(1.01)' },
        },
        'cratey-hop': {
          '0%': { transform: 'translateY(0)' },
          '40%': { transform: 'translateY(-10px)' },
          '100%': { transform: 'translateY(0)' },
        },
        'cratey-recoil': {
          '0%': { transform: 'translateY(0)' },
          '40%': { transform: 'translateY(-6px)' },
          '100%': { transform: 'translateY(0)' },
        },
        'cratey-cover': {
          '0%': { transform: 'rotateY(0deg) translateY(0)', filter: 'brightness(1)' },
          '100%': { transform: 'rotateY(12deg) translateY(2px)', filter: 'brightness(0.92)' },
        },
        'cratey-stealth': {
          '0%': { transform: 'scale(1)', opacity: '1' },
          '100%': { transform: 'scale(0.9)', opacity: '0.75' },
        },
        'cratey-sit-sleep': {
          '0%,100%': { transform: 'translateY(2px) rotate(-2deg)', opacity: '0.92' },
          '50%': { transform: 'translateY(4px) rotate(-1deg)', opacity: '0.9' },
        },
        'pal-lean': {
          '0%': { transform: 'rotate(0deg)' },
          '100%': { transform: 'rotate(-3deg) translateY(-2px)' },
        },
        'zip-zoom': {
          '0%': { transform: 'translateX(0)' },
          '60%': { transform: 'translateX(6px)' },
          '100%': { transform: 'translateX(0)' },
        },
        'ink-flash': {
          '0%': { opacity: '0.5' },
          '50%': { opacity: '1' },
          '100%': { opacity: '0.7' },
        },
      },
    },
  },
  plugins: [],
}
